﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsAppServices
{
    public class ClienteCl
    {
        public int id { get; set; }
        public string Nombre { get; set; }
        public string Direccion { get; set; }
    }
}
