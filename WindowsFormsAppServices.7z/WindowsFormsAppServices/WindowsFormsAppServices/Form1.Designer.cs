﻿namespace WindowsFormsAppServices
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.BtnGuardar = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.TxbEmP = new System.Windows.Forms.TextBox();
            this.bindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.btnSeleccionarFila = new System.Windows.Forms.Button();
            this.clienteClBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.clienteClBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteClBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteClBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnGuardar
            // 
            this.BtnGuardar.Location = new System.Drawing.Point(325, 288);
            this.BtnGuardar.Name = "BtnGuardar";
            this.BtnGuardar.Size = new System.Drawing.Size(75, 23);
            this.BtnGuardar.TabIndex = 0;
            this.BtnGuardar.Text = "button1";
            this.BtnGuardar.UseVisualStyleBackColor = true;
            this.BtnGuardar.Click += new System.EventHandler(this.BtnGuardar_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(282, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "label2";
            // 
            // TxbEmP
            // 
            this.TxbEmP.Location = new System.Drawing.Point(325, 262);
            this.TxbEmP.Name = "TxbEmP";
            this.TxbEmP.Size = new System.Drawing.Size(100, 20);
            this.TxbEmP.TabIndex = 3;
            this.TxbEmP.Text = "2";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToOrderColumns = true;
            this.dataGridView2.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Raised;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(39, 82);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(550, 150);
            this.dataGridView2.TabIndex = 5;
            // 
            // btnSeleccionarFila
            // 
            this.btnSeleccionarFila.Location = new System.Drawing.Point(480, 288);
            this.btnSeleccionarFila.Name = "btnSeleccionarFila";
            this.btnSeleccionarFila.Size = new System.Drawing.Size(75, 23);
            this.btnSeleccionarFila.TabIndex = 6;
            this.btnSeleccionarFila.Text = "SeleccionarFila";
            this.btnSeleccionarFila.UseVisualStyleBackColor = true;
            this.btnSeleccionarFila.Click += new System.EventHandler(this.btnSeleccionarFila_Click);
            // 
            // clienteClBindingSource1
            // 
            this.clienteClBindingSource1.DataSource = typeof(WindowsFormsAppServices.ClienteCl);
            // 
            // clienteClBindingSource
            // 
            this.clienteClBindingSource.DataSource = typeof(WindowsFormsAppServices.ClienteCl);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnSeleccionarFila);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.TxbEmP);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.BtnGuardar);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.bindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteClBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.clienteClBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnGuardar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TxbEmP;
        private System.Windows.Forms.BindingSource bindingSource1;
        private System.Windows.Forms.BindingSource clienteClBindingSource;
        private System.Windows.Forms.BindingSource clienteClBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Button btnSeleccionarFila;
    }
}

