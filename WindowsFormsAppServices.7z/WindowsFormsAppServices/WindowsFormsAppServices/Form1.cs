﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsAppServices
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnGuardar_Click(object sender, EventArgs e)
        {
            // List<ClienteCl> emp = new List<ClienteCl>();

             IEnumerable<ClienteCl> emp;
            ClienteCl empuno;
            bindingSource1.DataSource = new BindingSource();
            HttpClient cl = new HttpClient();
            cl.BaseAddress = new Uri("http://localhost:62366/api/");
            //cl.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
            HttpResponseMessage response = new HttpResponseMessage();
            //response = cl.GetAsync("Clientes/" + TxbEmP.Text).Result;
            response = cl.GetAsync("Clientes").Result;
            emp = response.Content.ReadAsAsync<IEnumerable<ClienteCl>>().Result;


            empuno = emp.First();
            response = cl.PostAsJsonAsync<ClienteCl>("Clientes",empuno).Result;

           // Listado de Clientes
            response = cl.GetAsync("Clientes").Result;
            emp = response.Content.ReadAsAsync<IEnumerable<ClienteCl>>().Result;

            bindingSource1.DataSource = emp;
            dataGridView2.DataSource = bindingSource1;
            dataGridView2.Refresh();
         }

        private void btnSeleccionarFila_Click(object sender, EventArgs e)
        {
            int index;
            index =  dataGridView2.CurrentRow.Index;
            MessageBox.Show("El Empleado: "+ dataGridView2.Rows[index].Cells[1].Value +" de la fila "+ index.ToString() + ", de la direccion "+dataGridView2.Rows[index].Cells[2].Value);
        }
    }
}
